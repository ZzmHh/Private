/**
 * 获客雷达 · 独立社媒拓客插件
 */
(function () {
  if (window.__leadRadarLoaded) return;
  window.__leadRadarLoaded = true;

  const ROOT = "lead-radar-root";
  let config = {};
  let queue = [];
  let seen = new Set();
  let scanning = false;
  let timer = null;

  const PLATFORM_LABELS = {
    tiktok: "TikTok",
    x: "X",
    xiaohongshu: "小红书",
    douyin: "抖音",
    facebook: "Facebook",
    web: "网页",
  };

  async function load() {
    const { lead_radar_queue = [] } = await chrome.storage.local.get("lead_radar_queue");
    queue = lead_radar_queue;
    const res = await LeadRadarMsg.send("lr_get_settings");
    if (res?.error) {
      status(res.error, "err");
      return;
    }
    config = res?.settings || {};
    render();
    badge();
  }

  async function save() {
    queue = queue.slice(0, 50);
    await chrome.storage.local.set({ lead_radar_queue: queue });
    badge();
    render();
  }

  function badge() {
    const n = queue.filter((l) => l.status === "new" && l.score >= (config.minScore || 72)).length;
    LeadRadarMsg.send("lr_badge", { count: n });
  }

  function ui(tag, cls, html) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  }

  function panel() {
    if (document.getElementById(ROOT)) return document.getElementById(ROOT);
    const root = ui("div", "lr-root");
    root.id = ROOT;
    root.innerHTML = `
      <button type="button" class="lr-fab" title="获客雷达">🎯<span class="lr-fab-badge">0</span></button>
      <div class="lr-drawer hidden">
        <header class="lr-head">
          <strong>获客雷达</strong>
          <span class="lr-plat"></span>
          <button type="button" class="lr-x">×</button>
        </header>
        <p class="lr-status">就绪</p>
        <div class="lr-bar">
          <label><input type="checkbox" id="lr-auto" checked /> 自动扫描</label>
          <button type="button" id="lr-scan" class="lr-btn">立即扫描</button>
        </div>
        <div class="lr-list"></div>
        <footer class="lr-foot">AI 拓客话术 · 人工确认后发送 · 独立插件 v1.0</footer>
      </div>`;
    document.body.appendChild(root);
    root.querySelector(".lr-fab").onclick = () => root.querySelector(".lr-drawer").classList.toggle("hidden");
    root.querySelector(".lr-x").onclick = () => root.querySelector(".lr-drawer").classList.add("hidden");
    root.querySelector("#lr-scan").onclick = () => scan(true);
    root.querySelector("#lr-auto").onchange = async (e) => {
      config.autoScan = e.target.checked;
      await chrome.storage.local.set({ lead_radar_settings: { ...config, autoScan: e.target.checked } });
      setupTimer();
    };
    const plat = LeadRadarDom.platform();
    root.querySelector(".lr-plat").textContent = PLATFORM_LABELS[plat] || plat;
    return root;
  }

  function status(msg, kind) {
    const el = document.querySelector(`#${ROOT} .lr-status`);
    if (el) {
      el.textContent = msg;
      el.className = `lr-status ${kind || ""}`.trim();
    }
  }

  function render() {
    const list = document.querySelector(`#${ROOT} .lr-list`);
    const fab = document.querySelector(`#${ROOT} .lr-fab-badge`);
    if (!list) return;
    const hot = queue.filter((l) => l.status === "new").length;
    if (fab) fab.textContent = String(hot);
    if (!queue.length) {
      list.innerHTML = `<p class="lr-empty">浏览 TikTok / 小红书 / X 的垂直内容，雷达会自动识别潜在客户。</p>`;
      return;
    }
    list.innerHTML = "";
    for (const lead of queue.slice(0, 15)) {
      const card = ui("div", `lr-card ${lead.score >= (config.minScore || 72) ? "hot" : ""}`);
      card.innerHTML = `
        <div class="lr-meta"><span class="lr-score">${lead.score}</span><b>${lead.persona || "客户"}</b><i>@${lead.author || ""}</i></div>
        <p class="lr-prev">${(lead.textPreview || "").slice(0, 100)}</p>
        <p class="lr-draft">${(lead.commentDraft || lead.dmDraft || "").slice(0, 180)}</p>
        <div class="lr-actions">
          <button type="button" data-a="fill" class="lr-btn">填入评论</button>
          <button type="button" data-a="copy" class="lr-btn ghost">复制</button>
          <button type="button" data-a="skip" class="lr-btn ghost">忽略</button>
        </div>`;
      card.querySelector('[data-a="fill"]').onclick = () => {
        const t = lead.commentDraft || lead.dmDraft || "";
        if (LeadRadarDom.fillInput(t)) status("已填入，请确认后发送", "ok");
        else {
          navigator.clipboard.writeText(t);
          status("未找到输入框，已复制", "warn");
        }
        lead.status = "drafted";
        save();
      };
      card.querySelector('[data-a="copy"]').onclick = () => {
        navigator.clipboard.writeText(lead.commentDraft || lead.dmDraft || "");
        status("已复制", "ok");
      };
      card.querySelector('[data-a="skip"]').onclick = () => {
        queue = queue.filter((x) => x.id !== lead.id);
        save();
      };
      list.appendChild(card);
    }
  }

  async function scan(manual) {
    if (scanning) return;
    scanning = true;
    status(manual ? "扫描本页…" : "自动扫描…");
    try {
      const raw = LeadRadarDom.extract();
      const batch = [];
      for (const item of raw) {
        if (seen.has(item.id)) continue;
        const local = LeadRadarSignals.score(item.text);
        if (local.score < 35 || local.negatives.length) continue;
        seen.add(item.id);
        batch.push({
          id: item.id,
          platform: item.platform,
          author: item.author,
          url: item.url,
          text: item.text,
          localScore: local.score,
          localHits: local.hits,
          localNegatives: local.negatives,
          _el: item.element,
        });
      }
      if (!batch.length) {
        const plat = LeadRadarDom.platform();
        if (plat === "douyin") {
          status(
            "抖音推荐页文字很少。请：① 点顶部搜索「跨境」「TikTok开店」② 打开视频评论区 ③ 再点「立即扫描」",
            "warn",
          );
        } else {
          status("本页暂无高意向内容，换搜索页或带评论的帖子", "warn");
        }
        return;
      }
      const payload = batch.map(({ _el, ...r }) => r);
      const { results, error } = await LeadRadarMsg.send("lr_analyze", { items: payload });
      if (error) throw new Error(error);
      let added = 0;
      for (const row of results || []) {
        if (!row.worthOutreach && row.score < (config.minScore || 72)) continue;
        if (queue.some((q) => q.id === row.id)) continue;
        const src = batch.find((b) => b.id === row.id);
        queue.unshift({ ...row, status: "new", foundAt: new Date().toISOString() });
        added++;
        if (row.score >= (config.minScore || 72) && src?._el) LeadRadarDom.highlight(src._el);
        if (config.autoDraft && row.score >= (config.minScore || 72)) {
          try {
            await navigator.clipboard.writeText(row.commentDraft || row.dmDraft || "");
          } catch {
            /* ignore */
          }
        }
      }
      await save();
      status(added ? `新增 ${added} 条精准客户` : "暂无达到阈值的客户", added ? "ok" : "warn");
    } catch (e) {
      status(e.message || "扫描失败", "err");
    } finally {
      scanning = false;
    }
  }

  function setupTimer() {
    if (timer) clearInterval(timer);
    if (!config.autoScan) return;
    timer = setInterval(() => scan(false), (config.scanSec || 4) * 1000);
  }

  function boot() {
    panel();
    status("获客雷达已启动，可点「立即扫描」", "ok");
    load().then(() => {
      const auto = document.querySelector("#lr-auto");
      if (auto) auto.checked = config.autoScan !== false;
      setupTimer();
      new MutationObserver(() => {
        if (!config.autoScan) return;
        clearTimeout(boot._d);
        boot._d = setTimeout(() => scan(false), 1500);
      }).observe(document.body, { childList: true, subtree: true });
      setTimeout(() => scan(false), 2500);
    });

    // 抖音/SPA 切页后刷新平台标签
    let lastHref = location.href;
    setInterval(() => {
      if (location.href !== lastHref) {
        lastHref = location.href;
        const el = document.querySelector(`#${ROOT} .lr-plat`);
        if (el) {
          const plat = LeadRadarDom.platform();
          el.textContent = PLATFORM_LABELS[plat] || plat;
        }
        if (config.autoScan !== false) setTimeout(() => scan(true), 2000);
      }
    }, 1500);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
