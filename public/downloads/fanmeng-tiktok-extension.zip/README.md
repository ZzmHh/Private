# 凡梦AI · TikTok Shop Chrome 助手

**凡梦只做 TikTok Shop。** 本插件仅在 TikTok 卖家中心域名下运行，不上线 Amazon / Shopify 等其他平台。

在 **卖家已登录的 TikTok 卖家中心** 内运行，无需 TikTok Open API / Partner 应用。  
数据通过浏览器读取当前页面，发送到凡梦 SaaS 生成 **客服话术、业绩诊断、广告库存利润** 分析。

## 功能（v0.4.1）

| 功能 | 说明 |
|------|------|
| **多区域消息识别** | 按 US / 东南亚 / 跨境 Global Shop 等多套 DOM 选择器识别聊天布局 |
| **消息 role 标注** | 面板展示最近消息，标 `买家` / `卖家` / `系统`，自动取**最后一条买家**消息 |
| **识别失败提示** | 无法识别时在面板明确提示：请选中一条消息后点「手动生成话术」 |
| **选中文字生成** | 选中聊天文字 → 右键 **凡梦生成回复**，或快捷键 **Ctrl+Shift+Y**（Mac：⌘⇧Y） |
| **自动监听新消息** | 聊天页 MutationObserver + 轮询；FAQ/问候/夜间 AI 命中后**自动填入并发送**；复杂问题为草稿 |
| **诊断包进度** | 与网站工作台一致，以服务端快照为准（概览 / 订单 / 广告 / 库存 0/4） |
| **多店铺** | 绑定本页店铺 + 下拉切换；快照按 `shopKey` 隔离 |
| **回复模板** | 草稿「存为模板」+ 下拉插入；弹窗可删除 |
| **同步本页** | 抓取 KPI/表格/文本并上传凡梦 |
| **业绩 / 利润** | 合并诊断包 + 已导入 CSV 后跑 Agent |

## 订阅与收费（与网站共用账号）

插件 **免费安装**，能力在凡梦服务端执行，与网站 **同一登录、同一套餐**：

| 套餐 | TikTok 插件 |
|------|-------------|
| 免费版 | 基础（同步 + 手动话术） |
| 成长版 ¥149 | ✅ 含 FAQ/售后/夜间 AI 自动发送 |
| 专业版及以上 | ✅ CSV 导入 + 一键运营 + Playwright 抓取 |

未订阅或试用结束时，面板会提示并引导 **「去网站订阅 / 续费」**。生产环境请在服务端配置 `APP_PUBLIC_URL`。详见 [docs/EXTENSION_MONETIZATION.md](../docs/EXTENSION_MONETIZATION.md)。

## 设置（插件弹窗）

- 弹窗顶部 **「📖 5 分钟上手教程」**：安装、客服、诊断分步说明（可折叠）
- **自动监听新消息**：默认开启  
- **自动同步诊断包**：进入非聊天后台页时自动同步本页  
- **定时同步**：可选间隔分钟  

## 诊断包怎么用

1. 依次打开卖家中心：**数据概览 → 订单 → 广告 → 库存**（URL 含 analytics/orders/ads 等）  
2. 每页可点 **「同步本页」** 或依赖自动同步  
3. 面板显示 `诊断包 3/4：✓数据概览 ✓订单 ✓广告 ○库存`  
4. 至少 **2/4** 后再点 **业绩诊断 / 广告库存利润** 效果更好  

## 卖家如何安装？

1. 在 **凡梦网站** 登录（试用或订阅标准版）
2. 工作台点击 **「安装 TikTok 插件」** 或顶部安装横幅
3. 按向导从 Chrome 商店安装，或下载 ZIP 后加载解压扩展
4. 插件弹窗登录同一凡梦账号 → 打开 TikTok 卖家中心

详细运营配置见 [docs/EXTENSION_INSTALL.md](../docs/EXTENSION_INSTALL.md) · 商店上架见 [docs/CHROME_WEB_STORE.md](../docs/CHROME_WEB_STORE.md)

## 安装（开发者模式）

1. 启动凡梦后端：`npm run dev:server`（默认 `http://127.0.0.1:8787`）  
2. Chrome 打开 `chrome://extensions/`  
3. 开启 **开发者模式** → **加载已解压的扩展程序**  
4. 选择本仓库 **`extension`** 文件夹  
5. 点击扩展图标 → 配置 API 地址 → **用凡梦网站同一账号登录**  
6. 打开 [TikTok 卖家中心](https://seller.tiktok.com/) 并 **刷新页面** → 右侧出现「凡梦AI」面板（首次会自动展开试用教程，也可点 **?** 查看）

生产环境请将 API 地址改为 `https://你的域名`（需 HTTPS，且服务端已部署）。

## 后端 API（已实现）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/extension/status` | 登录与快照状态 |
| POST | `/api/extension/snapshot` | 上传页面抓取 JSON |
| POST | `/api/extension/cs/suggest` | 买家话术（短回复） |
| POST | `/api/extension/analyze` | `growth` / `profit` / `service` 分析 |

网站工作台调用 Agent 时也可传 `useExtensionSnapshot: true` 使用最近插件同步的数据。

## 限制与合规

- 依赖 TikTok **网页 DOM**，改版后可能需要更新选择器。  
- **不会自动点击发送**，避免误回复与平台自动化风险。  
- 页面数据为 **样本/不完整**，利润分析仍可能需要卖家在凡梦内补充 SKU 成本。  
- 请在使用说明中告知卖家：辅助工具，非 TikTok 官方应用。

## 目录结构

```text
extension/
├── manifest.json
├── popup/           # 登录与设置
├── src/
│   ├── background.js
│   ├── content/     # 卖家中心浮动面板
│   └── lib/         # tiktok 常量、API、多区域选择器、消息解析
└── README.md
```

更完整的架构说明见仓库根目录 `docs/CHROME_EXTENSION.md`。
